import cheerio from 'cheerio';
import fetch from 'node-fetch';
import axios from "axios"
import { trackRequest } from "../../../lib/redis";
import { API_KEY, CREATOR } from '../../../settings';

export default async function handler(req, res) {
    if (req.method !== 'GET') {
        return res.status(405).json({
            status: false,
            creator: CREATOR,
            error: 'Method Not Allowed',
        });
    }

    const { dari, ke } = req.query;

    if (!dari) {
        return res.status(400).json({
            status: false, 
            creator: CREATOR, 
            error: 'missing dari parameter'
        });
    }
	
    if (!ke) {
        return res.status(400).json({
            status: false, 
            creator: CREATOR, 
            error: 'missing ke parameter'
        });
    }
    
    try {
        await trackRequest("/api/search/jarak");
        const result = await jarak(dari, ke);
        res.status(200).json({
            status: true,
            creator: CREATOR,
            data: result,
        });
    } catch (error) {
        res.status(500).json({
            status: false,
            creator: CREATOR,
            error: 'Internal Server Error:' + error,
        });
    }
}

async function jarak(dari, ke) {
	var html = (await axios(`https://www.google.com/search?q=${encodeURIComponent('jarak ' + dari + ' ke ' + ke)}&hl=id`)).data
	var $ = cheerio.load(html), obj = {}
	var img = html.split("var s=\'")?.[1]?.split("\'")?.[0]
	obj.img = /^data:.*?\/.*?;base64,/i.test(img) ? Buffer.from(img.split`,` [1], 'base64') : ''
	obj.desc = $('div.BNeawe.deIvCb.AP7Wnd').text()?.trim()
	return obj
}
